from django.shortcuts import render
from .models import Usuarios
from .models import Pedidos 

def home(request):
    return render(request,'usuarios/index.html')

def cardapioS(request):
    return render(request,'usuarios/cardapioSalgado.html')

def cardapioD(request):
    return render(request,'usuarios/cardapioDoce.html')

def cadastro(request):
    return render(request,'usuarios/cadastro.html')

def fazerpedido(request):
    return render(request,'usuarios/fazerpedido.html')


def usuarios(request):
    novo_usuario = Usuarios()
    novo_usuario.nome = request.POST.get('nome')
    novo_usuario.numero = request.POST.get('numero')
    novo_usuario.senha = request.POST.get('senha')
    novo_usuario.save()

    usuarios = {
        'usuarios': Usuarios.objects.all()

    } 
    return render(request, 'usuarios/usuarios.html', usuarios)


def pedido(request):
    novo_pedido = Pedidos()
    novo_pedido.pedido = request.POST.get('pedido')
    novo_pedido.pagamento = request.POST.get('pagamento')
    novo_pedido.endereco = request.POST.get('endereco')
    novo_pedido.receptor = request.POST.get('receptor')
    novo_pedido.quantidade = request.POST.get('quantidade')
    novo_pedido.save()

    pedidos = {
        'pedidos': Pedidos.objects.all()
    } 
    return render(request, 'usuarios/pedidos.html', pedidos)

def Apagar(request):
    Usuarios.objects.all().delete()
    return render(request, 'usuarios/usuarios.html')  

def ApagarPedidos(request):
    Pedidos.objects.all().delete()
    return render(request, 'usuarios/pedidos.html') 

def doce(request):
    novo_doce = doce()
    novo_doce.nome = request.POST.get('bolo de cenoura')
    novo_doce.descricao = request.POST.get('um lindo bolo de cenoura')
    novo_doce.preco = request.POST.get('R$4.00')
    novo_doce.save()

    doce = {
        'doce': doce.objects.all()
    } 