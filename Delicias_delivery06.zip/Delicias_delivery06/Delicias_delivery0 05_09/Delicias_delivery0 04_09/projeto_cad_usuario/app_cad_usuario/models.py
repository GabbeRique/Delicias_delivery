from django.db import models


class Usuarios(models.Model):
    id_usuario = models.AutoField(primary_key=True)
    nome = models.TextField(max_length=30)
    numero = models.TextField(max_length=13)
    senha = models.TextField(max_length=99)

class Pedidos(models.Model):
    id_pedido = models.AutoField(primary_key=True)
    pedido = models.TextField(max_length=30)
    pagamento = models.TextField(max_length=30)
    endereco = models.TextField(max_length=30)
    receptor = models.TextField(max_length=30)
    quantidade = models.TextField(max_length=3)

class Vendedor(models.Model):
    pass 

class Comida(models.Model):
    pass