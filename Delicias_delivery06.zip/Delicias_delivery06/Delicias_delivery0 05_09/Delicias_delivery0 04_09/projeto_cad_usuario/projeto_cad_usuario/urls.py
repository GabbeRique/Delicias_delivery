
from django.urls import path
from app_cad_usuario import views

urlpatterns = [
   path('',views.home,name='home'),
   path('Home/', views.Apagar, name = 'Home/'),
   path('Home/Apagado/', views.ApagarPedidos, name = 'Home/Apagado/'),
   path('usuarios/listausuarios/',views.usuarios,name='lista_usuarios'),
   path('usuarios/cadastro/',views.cadastro,name='cadastro'),
   path('usuarios/pedidos/',views.pedido,name='pedidos'),
   path('usuarios/fazerpedidos/',views.fazerpedido, name='fazerpedidos'),
   path('usuarios/cardapioD/',views.cardapioD, name='cardapioDoce'),
   path('usuarios/cardapioS/',views.cardapioS, name='cardapioSalgado'),
]

