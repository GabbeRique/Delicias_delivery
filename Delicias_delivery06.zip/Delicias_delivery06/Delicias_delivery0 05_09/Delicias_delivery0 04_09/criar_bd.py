print('Criando banco de dados')
# importando o SQLite
import sqlite3 as lite

# Criando conexão
con = lite.connect('Delicias_delivery0 04_09\projeto_cad_usuario\db.sqlite3')

# Criando tabela
with con:
    cur = con.cursor()
    cur.execute("CREATE TABLE doce(id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT, descricao TEXT, preco TEXT)")

print('Criando banco de dados criado com sucesso!')



